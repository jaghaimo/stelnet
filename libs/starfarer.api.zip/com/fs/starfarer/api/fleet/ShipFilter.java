/**
 * 
 */
package com.fs.starfarer.api.fleet;

public interface ShipFilter {
	boolean isAvailable(String variantId);
}