package com.fs.starfarer.api.combat.listeners;

public interface AdvanceableListener {
	void advance(float amount);
}
