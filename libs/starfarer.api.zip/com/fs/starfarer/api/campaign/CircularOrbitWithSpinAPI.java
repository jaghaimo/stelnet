package com.fs.starfarer.api.campaign;

public interface CircularOrbitWithSpinAPI {

	float getSpinVel();
	void setSpinVel(float spinVel);

}
