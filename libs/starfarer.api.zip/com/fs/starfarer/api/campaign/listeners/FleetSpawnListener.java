package com.fs.starfarer.api.campaign.listeners;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;

/**
 * Unused.
 */
public interface FleetSpawnListener {
	void reportFleetSpawnedToListener(CampaignFleetAPI fleet);
}
