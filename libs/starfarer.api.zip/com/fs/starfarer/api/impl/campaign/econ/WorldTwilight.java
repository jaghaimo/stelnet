package com.fs.starfarer.api.impl.campaign.econ;


public class WorldTwilight extends WorldFarming {

	public WorldTwilight() {
		super(ConditionData.WORLD_TWILIGHT_FARMING_MULT, ConditionData.WORLD_TWILIGHT_MACHINERY_MULT);
	}

}
