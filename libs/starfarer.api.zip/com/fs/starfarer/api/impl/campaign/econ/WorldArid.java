package com.fs.starfarer.api.impl.campaign.econ;


public class WorldArid extends WorldFarming {

	public WorldArid() {
		super(ConditionData.WORLD_ARID_FARMING_MULT, ConditionData.WORLD_ARID_MACHINERY_MULT);
	}

}
