package com.fs.starfarer.api.impl.campaign.econ;


public class WorldFarming extends BaseMarketConditionPlugin {

	public WorldFarming(float foodMult, float machineryMult) {
	}
	
	public boolean showIcon() {
		return false;
	}
	
	public WorldFarming(float foodMult, float machineryMult, float maxFood) {
	}

	public void apply(String id) {
	}

	public void unapply(String id) {
	}

}




