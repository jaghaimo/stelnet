package com.fs.starfarer.api.impl.campaign.econ;


public class WorldDesert extends WorldFarming {

	public WorldDesert() {
		super(ConditionData.WORLD_DESERT_FARMING_MULT, ConditionData.WORLD_DESERT_MACHINERY_MULT);
	}

}
