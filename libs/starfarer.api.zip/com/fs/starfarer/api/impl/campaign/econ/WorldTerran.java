package com.fs.starfarer.api.impl.campaign.econ;


public class WorldTerran extends WorldFarming {

	public WorldTerran() {
		super(ConditionData.WORLD_TERRAN_FARMING_MULT, ConditionData.WORLD_TERRAN_MACHINERY_MULT);
	}

}
